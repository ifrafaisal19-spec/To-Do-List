
class Task {
  constructor(text, completed = false, id = Date.now() + Math.random()) {
    this.id = id;
    this.text = text;
    this.completed = completed;
  }
}

class TodoApp {
  constructor(storageKey) {
    this.storageKey = storageKey;
    this.tasks = this.load();
    this.filter = 'all';
  }

  load() {
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (!raw) return [];
      return JSON.parse(raw).map(t => new Task(t.text, t.completed, t.id));
    } catch (e) {
      console.error('Failed to load tasks:', e);
      return [];
    }
  }

  save() {
    localStorage.setItem(this.storageKey, JSON.stringify(this.tasks));
  }

  addTask(text) {
    const trimmed = text.trim();
    if (!trimmed) return;
    this.tasks.unshift(new Task(trimmed));
    this.save();
  }

  toggleTask(id) {
    const task = this.tasks.find(t => t.id === id);
    if (task) {
      task.completed = !task.completed;
      this.save();
    }
  }

  deleteTask(id) {
    this.tasks = this.tasks.filter(t => t.id !== id);
    this.save();
  }

  clearCompleted() {
    this.tasks = this.tasks.filter(t => !t.completed);
    this.save();
  }

  setFilter(filter) {
    this.filter = filter;
  }

  getVisibleTasks() {
    if (this.filter === 'active') return this.tasks.filter(t => !t.completed);
    if (this.filter === 'done') return this.tasks.filter(t => t.completed);
    return this.tasks;
  }

  getStats() {
    const done = this.tasks.filter(t => t.completed).length;
    return { total: this.tasks.length, done };
  }
}



const app = new TodoApp('todo-tasks');

const taskForm = document.getElementById('taskForm');
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');
const statusLine = document.getElementById('statusLine');
const filterButtons = document.querySelectorAll('.filter-btn[data-filter]');
const clearDoneBtn = document.getElementById('clearDone');

function render() {
  const visible = app.getVisibleTasks();
  taskList.innerHTML = '';

  if (visible.length === 0) {
    const empty = document.createElement('li');
    empty.className = 'empty-state';
    empty.textContent = app.tasks.length === 0
      ? 'no tasks yet — add one above'
      : 'nothing here for this filter';
    taskList.appendChild(empty);
  } else {
    visible.forEach(task => {
      const li = document.createElement('li');
      li.className = 'task-item' + (task.completed ? ' done' : '');

      const checkbox = document.createElement('button');
      checkbox.className = 'task-checkbox' + (task.completed ? ' checked' : '');
      checkbox.textContent = task.completed ? '✓' : '';
      checkbox.setAttribute('aria-label', 'toggle task complete');
      checkbox.onclick = () => { app.toggleTask(task.id); render(); };

      const text = document.createElement('span');
      text.className = 'task-text';
      text.textContent = task.text;

      const del = document.createElement('button');
      del.className = 'task-delete';
      del.textContent = '✕';
      del.setAttribute('aria-label', 'delete task');
      del.onclick = () => { app.deleteTask(task.id); render(); };

      li.appendChild(checkbox);
      li.appendChild(text);
      li.appendChild(del);
      taskList.appendChild(li);
    });
  }

  const { total, done } = app.getStats();
  statusLine.textContent = `${total} task${total !== 1 ? 's' : ''} · ${done} done`;
}

taskForm.addEventListener('submit', (e) => {
  e.preventDefault();
  app.addTask(taskInput.value);
  taskInput.value = '';
  render();
});

filterButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    filterButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    app.setFilter(btn.dataset.filter);
    render();
  });
});

clearDoneBtn.addEventListener('click', () => {
  app.clearCompleted();
  render();
});


function typeText(el, text, speed = 40) {
  let i = 0;
  const interval = setInterval(() => {
    el.textContent = text.slice(0, i + 1);
    i++;
    if (i === text.length) clearInterval(interval);
  }, speed);
}

typeText(document.getElementById('typedTitle'), 'organize your day');

render();
